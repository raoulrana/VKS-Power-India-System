"use client"

import { useState } from "react"
import { Calculator, Zap, IndianRupee, Leaf } from "lucide-react"

export function SavingsCalculator() {
  const [monthlyBill, setMonthlyBill] = useState(5000)

  // Calculate savings (rough estimation)
  const systemSize = Math.ceil(monthlyBill / 1000) // Approx kW needed
  const annualSavings = monthlyBill * 12 * 0.85 // 85% savings
  const systemCost = systemSize * 55000 // Approx cost per kW after subsidy
  const paybackYears = Math.round(systemCost / annualSavings * 10) / 10
  const lifetimeSavings = annualSavings * 25 // 25 year lifespan
  const co2Reduction = systemSize * 1.5 // Tons per year

  return (
    <section className="py-20 md:py-28 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-block text-sm font-semibold text-secondary uppercase tracking-wider mb-4">
            Savings Calculator
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-balance">
            Calculate Your Solar Savings
          </h2>
          <p className="text-lg text-primary-foreground/80 leading-relaxed">
            Enter your current monthly electricity bill to see how much you can save with solar.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Calculator Input */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 md:p-8 mb-8">
            <label className="block mb-4">
              <span className="text-sm font-medium text-primary-foreground/80">
                Your Monthly Electricity Bill
              </span>
              <div className="mt-2 flex items-center gap-4">
                <span className="text-2xl font-bold">Rs.</span>
                <input
                  type="range"
                  min="1000"
                  max="50000"
                  step="500"
                  value={monthlyBill}
                  onChange={(e) => setMonthlyBill(Number(e.target.value))}
                  className="flex-1 h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-secondary"
                />
                <span className="text-2xl font-bold min-w-[100px] text-right">
                  {monthlyBill.toLocaleString()}
                </span>
              </div>
            </label>
          </div>

          {/* Results Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-secondary" />
              </div>
              <p className="text-3xl md:text-4xl font-bold mb-1">{systemSize} kW</p>
              <p className="text-sm text-primary-foreground/70">Recommended System</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <IndianRupee className="w-6 h-6 text-secondary" />
              </div>
              <p className="text-3xl md:text-4xl font-bold mb-1">
                {Math.round(annualSavings / 1000)}K
              </p>
              <p className="text-sm text-primary-foreground/70">Annual Savings</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calculator className="w-6 h-6 text-secondary" />
              </div>
              <p className="text-3xl md:text-4xl font-bold mb-1">{paybackYears} Yrs</p>
              <p className="text-sm text-primary-foreground/70">Payback Period</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="w-6 h-6 text-secondary" />
              </div>
              <p className="text-3xl md:text-4xl font-bold mb-1">{co2Reduction}T</p>
              <p className="text-sm text-primary-foreground/70">CO2 Reduced/Year</p>
            </div>
          </div>

          {/* Lifetime Savings */}
          <div className="mt-8 bg-secondary text-secondary-foreground rounded-2xl p-6 md:p-8 text-center">
            <p className="text-sm font-medium mb-2">25-Year Lifetime Savings</p>
            <p className="text-4xl md:text-5xl font-bold">
              Rs. {(lifetimeSavings / 100000).toFixed(1)} Lakhs
            </p>
          </div>

          <p className="text-center text-sm text-primary-foreground/60 mt-6">
            * Calculations are approximate and may vary based on actual site conditions, 
            electricity tariff, and system configuration. Contact us for accurate estimates.
          </p>
        </div>
      </div>
    </section>
  )
}
