import { Shield, Clock, Award, Headphones, IndianRupee, FileCheck } from "lucide-react"

const reasons = [
  {
    icon: Shield,
    title: "Guaranteed Savings",
    description: "Save up to 90% on your electricity bills with our high-efficiency solar systems.",
  },
  {
    icon: Clock,
    title: "13+ Years Experience",
    description: "Founded in 2012 by Vikas Rana, we bring over a decade of expertise in solar installations.",
  },
  {
    icon: Award,
    title: "Premium Brands Only",
    description: "We use only trusted brands like Waaree, Adani Solar, Premier Energies & Tata Power Solar.",
  },
  {
    icon: IndianRupee,
    title: "Subsidy Assistance",
    description: "Complete support with Central and Delhi Government solar subsidies for maximum savings.",
  },
  {
    icon: FileCheck,
    title: "Net Metering Support",
    description: "End-to-end assistance with net metering application and approval process.",
  },
  {
    icon: Headphones,
    title: "After-Sales Service",
    description: "Dedicated support team for maintenance, repairs, and performance monitoring.",
  },
]

export function WhyChooseUs() {
  return (
    <section id="why-us" className="py-20 md:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <div>
            <span className="inline-block text-sm font-semibold text-primary uppercase tracking-wider mb-4">
              Why Choose Us
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
              We Handle Everything. You Just Save.
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              From free home visit and rooftop survey to 3D solar design, installation, 
              and net metering - we provide complete end-to-end solar solutions. Our team 
              ensures hassle-free installation while you enjoy savings from day one.
            </p>

            {/* Process Steps */}
            <div className="space-y-4">
              {[
                "Free Home Visit & Rooftop Survey",
                "Free 3D Solar System Design",
                "Hassle-Free Installation & Subsidy Support",
                "Net Metering Application & Approval",
                "You Save. We Maintain.",
              ].map((step, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0">
                    {index + 1}
                  </div>
                  <p className="text-foreground font-medium">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Grid */}
          <div className="grid sm:grid-cols-2 gap-4 lg:gap-6">
            {reasons.map((reason, index) => (
              <div
                key={index}
                className="bg-card border border-border rounded-xl p-5 hover:border-primary/30 transition-colors"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <reason.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{reason.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {reason.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
