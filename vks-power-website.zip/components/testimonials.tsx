"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"

const testimonials = [
  {
    name: "Rajesh Kumar",
    location: "Rohini, Delhi",
    system: "5 kW Residential",
    rating: 5,
    text: "Excellent service from VKS Power! They installed a 5 kW system on my rooftop. My electricity bill has reduced from Rs. 8000 to almost zero. The team was professional and completed the installation in just 2 days.",
  },
  {
    name: "Priya Sharma",
    location: "Pitampura, Delhi",
    system: "3 kW Residential",
    rating: 5,
    text: "Very satisfied with the solar installation. VKS Power helped us with all the paperwork for government subsidy and net metering. The after-sales service is also excellent. Highly recommended!",
  },
  {
    name: "Amit Enterprises",
    location: "Narela Industrial Area",
    system: "50 kW Commercial",
    rating: 5,
    text: "We installed 50 kW solar system for our factory. VKS Power delivered the project on time with high-quality Waaree panels. Our electricity costs have reduced by 70%. Best investment for our business.",
  },
  {
    name: "Dr. Sunita Verma",
    location: "Model Town, Delhi",
    system: "6 kW Residential",
    rating: 5,
    text: "From the initial survey to final installation, everything was smooth. Vikas ji personally ensured that the work was done perfectly. The real-time monitoring app helps me track generation daily.",
  },
  {
    name: "Green Valley Farms",
    location: "Bawana, Delhi",
    system: "Solar Pump 10 HP",
    rating: 5,
    text: "We got a 10 HP solar pump installed for our farm. Now we dont have to worry about electricity bills for irrigation. PM-KUSUM subsidy was processed smoothly by the VKS team.",
  },
]

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section id="testimonials" className="py-20 md:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-sm font-semibold text-primary uppercase tracking-wider mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            What Our Customers Say
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            {"Don't just take our word for it. Here's what our happy customers have to say about their solar experience with VKS Power."}
          </p>
        </div>

        {/* Testimonials Slider */}
        <div className="relative max-w-4xl mx-auto">
          <div className="bg-card border border-border rounded-2xl p-8 md:p-12">
            {/* Quote Icon */}
            <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mb-6">
              <Quote className="w-6 h-6 text-secondary" />
            </div>

            {/* Rating */}
            <div className="flex gap-1 mb-4">
              {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-secondary text-secondary" />
              ))}
            </div>

            {/* Testimonial Text */}
            <p className="text-lg md:text-xl text-foreground mb-8 leading-relaxed">
              {`"${testimonials[currentIndex].text}"`}
            </p>

            {/* Author Info */}
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <p className="font-semibold text-foreground">
                  {testimonials[currentIndex].name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {testimonials[currentIndex].location} • {testimonials[currentIndex].system}
                </p>
              </div>

              {/* Navigation */}
              <div className="flex gap-2">
                <button
                  onClick={prevTestimonial}
                  className="w-10 h-10 border border-border rounded-full flex items-center justify-center hover:bg-muted transition-colors"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={nextTestimonial}
                  className="w-10 h-10 border border-border rounded-full flex items-center justify-center hover:bg-muted transition-colors"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? "bg-primary" : "bg-border"
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Stats Bar */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 bg-card border border-border rounded-2xl p-6 md:p-8">
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-primary">4.9</p>
            <p className="text-sm text-muted-foreground">Google Rating</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-primary">1000+</p>
            <p className="text-sm text-muted-foreground">Happy Customers</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-primary">98%</p>
            <p className="text-sm text-muted-foreground">Satisfaction Rate</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-primary">500+</p>
            <p className="text-sm text-muted-foreground">5-Star Reviews</p>
          </div>
        </div>
      </div>
    </section>
  )
}
