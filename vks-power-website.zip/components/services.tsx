import { Home, Building2, Factory, Tractor, Droplets, Wrench } from "lucide-react"

const services = [
  {
    icon: Home,
    title: "Residential Solar",
    description: "Power your home with clean energy. Rooftop solar systems designed for maximum savings and efficiency.",
    features: ["Net Metering Support", "Government Subsidy", "25 Year Warranty"],
  },
  {
    icon: Building2,
    title: "Commercial Solar",
    description: "Reduce operational costs for your business with customized commercial solar power plants.",
    features: ["High Capacity Systems", "Quick ROI", "Maintenance Support"],
  },
  {
    icon: Factory,
    title: "Industrial Solar",
    description: "Large-scale solar installations for factories and industrial units with captive power solutions.",
    features: ["MW Scale Projects", "Grid Integration", "Power Purchase Agreements"],
  },
  {
    icon: Tractor,
    title: "Agricultural Solar",
    description: "Solar solutions designed specifically for farms including solar pumps and irrigation systems.",
    features: ["Solar Water Pumps", "PM-KUSUM Scheme", "Rural Electrification"],
  },
  {
    icon: Droplets,
    title: "Solar Water Pumps",
    description: "AC and DC solar pumps for irrigation, drinking water, and industrial applications.",
    features: ["Submersible Pumps", "Surface Pumps", "Auto-tracking Systems"],
  },
  {
    icon: Wrench,
    title: "O&M Services",
    description: "Comprehensive operation and maintenance services to ensure optimal system performance.",
    features: ["Regular Inspection", "Cleaning Services", "Performance Monitoring"],
  },
]

export function Services() {
  return (
    <section id="services" className="py-20 md:py-28 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-sm font-semibold text-primary uppercase tracking-wider mb-4">
            Our Services
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Complete Solar Solutions for Every Need
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            From site survey to installation and maintenance, we handle everything. 
            Get end-to-end solar solutions with government subsidy assistance.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-background border border-border rounded-2xl p-6 lg:p-8 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
            >
              {/* Icon */}
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <service.icon className="w-7 h-7 text-primary" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {service.description}
              </p>

              {/* Features */}
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li
                    key={featureIndex}
                    className="flex items-center gap-2 text-sm text-muted-foreground"
                  >
                    <span className="w-1.5 h-1.5 bg-secondary rounded-full" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
