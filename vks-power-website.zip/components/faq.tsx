"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

const faqs = [
  {
    question: "What is the cost of installing a solar system?",
    answer: "The cost depends on system size. For residential systems, expect approximately Rs. 55,000-65,000 per kW after government subsidy. A 3 kW system for an average home costs around Rs. 1.5-2 lakhs after subsidy. Commercial and industrial systems have different pricing structures. Contact us for a free customized quote.",
  },
  {
    question: "What government subsidies are available for solar?",
    answer: "Under the PM Surya Ghar scheme, residential consumers can get up to 60% subsidy for systems up to 2 kW, and 40% for 2-3 kW systems. Additional state subsidies may be available in Delhi. We handle all subsidy paperwork and ensure you get maximum benefits.",
  },
  {
    question: "How much can I save on my electricity bill?",
    answer: "Most customers save 80-90% on their electricity bills. A 3 kW system typically generates 12-15 units per day, which is sufficient for a home with Rs. 3000-5000 monthly bill. With net metering, excess power is exported to the grid and credited to your account.",
  },
  {
    question: "What is the warranty on solar panels?",
    answer: "All our solar panels come with 25-year performance warranty from the manufacturer (Waaree, Adani, Tata Power Solar, Premier Energies). Inverters typically have 5-10 year warranty. We also provide 1 year free maintenance service.",
  },
  {
    question: "How long does installation take?",
    answer: "Typical residential installation takes 2-3 days. Commercial projects may take 1-2 weeks depending on system size. The complete process including survey, design, installation, and net metering approval usually takes 4-6 weeks.",
  },
  {
    question: "What is net metering and how does it work?",
    answer: "Net metering allows you to export excess solar power to the grid. Your meter records both import and export. At the end of billing cycle, you only pay for net units consumed. If you export more than you import, the credit is carried forward. We handle the complete net metering application process.",
  },
  {
    question: "Do solar panels work during monsoon and cloudy days?",
    answer: "Yes, solar panels generate power even on cloudy days, though at reduced efficiency (30-50% of normal). High-quality panels from brands we use perform better in low-light conditions. Annual generation accounts for all weather variations.",
  },
  {
    question: "What maintenance is required for solar systems?",
    answer: "Solar systems require minimal maintenance. Regular cleaning of panels (monthly or after dust storms) and annual inspection of electrical connections is recommended. We offer comprehensive AMC (Annual Maintenance Contract) packages.",
  },
]

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-sm font-semibold text-primary uppercase tracking-wider mb-4">
            FAQ
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Have questions about solar? Here are answers to the most common queries 
            from our customers.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors"
              >
                <span className="font-semibold text-foreground pr-4">
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform ${
                    openIndex === index ? "rotate-180" : ""
                  }`}
                />
              </button>
              {openIndex === index && (
                <div className="px-6 pb-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-4">
            {"Still have questions? We're here to help!"}
          </p>
          <a
            href="tel:+919711110136"
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Call Us: 097111 10136
          </a>
        </div>
      </div>
    </section>
  )
}
