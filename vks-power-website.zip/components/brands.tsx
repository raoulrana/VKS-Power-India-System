const brands = [
  {
    name: "Waaree",
    logo: "/brands/waaree.png",
    description: "India's Largest Solar Panel Manufacturer",
  },
  {
    name: "Adani Solar",
    logo: "/brands/adani.png",
    description: "Premium Quality Solar Modules",
  },
  {
    name: "Premier Energies",
    logo: "/brands/premier.png",
    description: "High Efficiency Solar Cells",
  },
  {
    name: "Tata Power Solar",
    logo: "/brands/tata.png",
    description: "Trusted Solar Solutions",
  },
]

export function Brands() {
  return (
    <section id="brands" className="py-20 md:py-28 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-sm font-semibold text-primary uppercase tracking-wider mb-4">
            Our Partners
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            {"We Install India's Most Trusted Solar Brands"}
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            We only use high-quality solar panels from India&apos;s leading manufacturers 
            to ensure maximum efficiency, durability, and performance for your solar system.
          </p>
        </div>

        {/* Brands Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
          {brands.map((brand, index) => (
            <div
              key={index}
              className="bg-background border border-border rounded-2xl p-6 lg:p-8 flex flex-col items-center text-center hover:border-primary/30 hover:shadow-lg transition-all"
            >
              {/* Logo Placeholder */}
              <div className="w-24 h-24 md:w-32 md:h-32 bg-muted rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl md:text-3xl font-bold text-primary">
                  {brand.name.charAt(0)}
                </span>
              </div>
              <h3 className="font-semibold text-foreground mb-1">{brand.name}</h3>
              <p className="text-sm text-muted-foreground">{brand.description}</p>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-12 bg-primary/5 border border-primary/20 rounded-2xl p-6 md:p-8 text-center">
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            All our solar panels come with <span className="text-foreground font-semibold">25-year performance warranty</span> and 
            are certified by BIS (Bureau of Indian Standards). We ensure that you get the best quality 
            products at competitive prices with complete government subsidy support.
          </p>
        </div>
      </div>
    </section>
  )
}
