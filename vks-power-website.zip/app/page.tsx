import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Services } from "@/components/services"
import { WhyChooseUs } from "@/components/why-choose-us"
import { Brands } from "@/components/brands"
import { SavingsCalculator } from "@/components/savings-calculator"
import { Testimonials } from "@/components/testimonials"
import { FAQ } from "@/components/faq"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <Services />
      <WhyChooseUs />
      <Brands />
      <SavingsCalculator />
      <Testimonials />
      <FAQ />
      <Contact />
      <Footer />
    </main>
  )
}
